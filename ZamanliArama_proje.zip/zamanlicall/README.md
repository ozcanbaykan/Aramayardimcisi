# Zamanlı Arama (Android)
Seçtiğin saatte, seçtiğin kişiyi otomatik arar. Kilit ekranı kapalıyken (şifre/desen yokken) ve telefon açıkken çalışır.

## APK'yı almak
**Android Studio ile:** Android Studio'yu aç → Open → bu klasörü seç → Gradle eşitlemesini bekle →
Build > Build APK(s). APK: app/build/outputs/apk/debug/app-debug.apk. Telefona kopyalayıp kur
(Ayarlar'da "bilinmeyen kaynaklardan yüklemeye" izin ver).
**Android Studio olmadan:** klasörü bir GitHub deposuna yükle → Actions sekmesi → "APK derle" → çıkan APK'yı indir.

## İlk kullanım (önemli)
Uygulama üstte eksik izinleri gösterir; "İzinleri düzelt" düğmesine basıp sırayla ver:
1. Telefon araması izni  2. Alarmlar ve hatırlatıcılar  3. Pil optimizasyonundan muaf tut.
Bazı markalarda (Xiaomi, Huawei, Oppo, Samsung) ayrıca "otomatik başlatma / arka planda çalışma"
iznini uygulama için açman gerekebilir.

## Nasıl çalışır
- Zamanlama AlarmManager.setAlarmClock ile yapılır (uyku modunda bile tam saatinde çalışır; durum çubuğunda alarm simgesi görünür).
- Saat gelince TelecomManager.placeCall ile arama başlatılır. Üretici kısıtı yüzünden başlatılamazsa
  ekranı açan "Aramak için dokun" bildirimi gösterilir.
- Telefon yeniden başlarsa alarmlar otomatik yeniden kurulur. Telefon kapalıyken kaçan tek seferlik aramalar geçmişe yazılır.
- Tek seferlik veya her gün tekrarlayan arama seçilebilir.
