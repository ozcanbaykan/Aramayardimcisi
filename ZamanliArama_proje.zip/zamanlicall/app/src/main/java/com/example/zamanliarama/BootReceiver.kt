package com.example.zamanliarama

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Telefon yeniden başlayınca ya da saat değişince alarmları yeniden kurar. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val now = System.currentTimeMillis()
        for (call in Store.all(ctx)) {
            when {
                call.time > now -> Scheduler.schedule(ctx, call)
                call.daily -> {
                    val next = call.copy(time = Scheduler.nextFuture(call.time, now))
                    Store.upsert(ctx, next)
                    Scheduler.schedule(ctx, next)
                }
                else -> {
                    Store.log(ctx, "Telefon kapalıyken kaçan arama: ${call.name}")
                    Store.remove(ctx, call.id)
                }
            }
        }
    }
}
