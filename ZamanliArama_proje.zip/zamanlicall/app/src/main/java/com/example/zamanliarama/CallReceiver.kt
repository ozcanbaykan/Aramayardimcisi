package com.example.zamanliarama

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.telecom.TelecomManager
import androidx.core.app.NotificationCompat

/** Alarm zamanı geldiğinde çalışır ve aramayı başlatır. */
class CallReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val call = Store.get(ctx, id) ?: return

        val ok = placeCall(ctx, call)
        if (ok) {
            Store.log(ctx, "Aranıyor: ${call.name} (${call.number})")
        } else {
            Store.log(ctx, "Arama doğrudan başlatılamadı, bildirim gönderildi: ${call.name}")
            notifyFallback(ctx, call)
        }

        if (call.daily) {
            val next = call.copy(time = Scheduler.nextFuture(call.time))
            Store.upsert(ctx, next)
            Scheduler.schedule(ctx, next)
        } else {
            Store.remove(ctx, call.id)
        }
    }

    private fun placeCall(ctx: Context, call: ScheduledCall): Boolean {
        if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return false
        }
        return try {
            ctx.getSystemService(TelecomManager::class.java)
                .placeCall(Uri.fromParts("tel", call.number, null), Bundle())
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Doğrudan arama engellenirse: ekranı açan, dokununca arayan yüksek öncelikli bildirim. */
    private fun notifyFallback(ctx: Context, call: ScheduledCall) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("arama", "Zamanlı arama", NotificationManager.IMPORTANCE_HIGH)
        )
        val dial = Intent(Intent.ACTION_CALL, Uri.fromParts("tel", call.number, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            ctx, call.id, dial, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, "arama")
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle("Arama zamanı: ${call.name}")
            .setContentText("Aramak için dokun (${call.number})")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(pi, true)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(call.id, n)
    }
}
