package com.example.zamanliarama

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.ContactsContract
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val picked = Calendar.getInstance().apply {
        add(Calendar.MINUTE, 5)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    private val fmt = SimpleDateFormat("d MMMM yyyy, EEEE  HH:mm", Locale("tr"))

    private lateinit var etName: EditText
    private lateinit var etNumber: EditText
    private lateinit var btnDate: Button
    private lateinit var btnTime: Button
    private lateinit var cbDaily: CheckBox
    private lateinit var listCalls: LinearLayout
    private lateinit var tvLog: TextView
    private lateinit var permStatus: TextView
    private lateinit var btnFixPerms: Button

    private val contactPicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uri = r.data?.data ?: return@registerForActivityResult
        val cols = arrayOf(
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        )
        contentResolver.query(uri, cols, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                etNumber.setText(c.getString(0))
                etName.setText(c.getString(1))
            }
        }
    }

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "Zamanlı Arama"

        etName = findViewById(R.id.etName)
        etNumber = findViewById(R.id.etNumber)
        btnDate = findViewById(R.id.btnDate)
        btnTime = findViewById(R.id.btnTime)
        cbDaily = findViewById(R.id.cbDaily)
        listCalls = findViewById(R.id.listCalls)
        tvLog = findViewById(R.id.tvLog)
        permStatus = findViewById(R.id.permStatus)
        btnFixPerms = findViewById(R.id.btnFixPerms)

        findViewById<Button>(R.id.btnContact).setOnClickListener {
            contactPicker.launch(
                Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
            )
        }
        btnDate.setOnClickListener {
            DatePickerDialog(this, { _, y, m, d ->
                picked.set(y, m, d)
                refreshButtons()
            }, picked.get(Calendar.YEAR), picked.get(Calendar.MONTH), picked.get(Calendar.DAY_OF_MONTH)).show()
        }
        btnTime.setOnClickListener {
            TimePickerDialog(this, { _, h, min ->
                picked.set(Calendar.HOUR_OF_DAY, h)
                picked.set(Calendar.MINUTE, min)
                picked.set(Calendar.SECOND, 0)
                refreshButtons()
            }, picked.get(Calendar.HOUR_OF_DAY), picked.get(Calendar.MINUTE), true).show()
        }
        findViewById<Button>(R.id.btnAdd).setOnClickListener { addCall() }
        btnFixPerms.setOnClickListener { fixPermissions() }

        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(permissionsToAsk(), 1)
        }
        refreshButtons()
    }

    override fun onResume() {
        super.onResume()
        refreshList()
        refreshPermissionBanner()
    }

    private fun permissionsToAsk(): Array<String> {
        val list = mutableListOf(Manifest.permission.CALL_PHONE)
        if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
        return list.toTypedArray()
    }

    private fun refreshButtons() {
        btnDate.text = SimpleDateFormat("d MMM yyyy", Locale("tr")).format(picked.time)
        btnTime.text = SimpleDateFormat("HH:mm", Locale("tr")).format(picked.time)
    }

    private fun addCall() {
        val number = etNumber.text.toString().trim()
        if (number.isEmpty()) {
            toast("Telefon numarası gir"); return
        }
        val when_ = picked.timeInMillis
        if (when_ <= System.currentTimeMillis()) {
            toast("Zaman geçmişte, ileri bir zaman seç"); return
        }
        if (!Scheduler.canScheduleExact(this)) {
            toast("Önce 'Alarmlar ve hatırlatıcılar' iznini ver")
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            return
        }
        val name = etName.text.toString().trim().ifEmpty { number }
        val call = ScheduledCall(Store.nextId(this), name, number, when_, cbDaily.isChecked)
        Store.upsert(this, call)
        Scheduler.schedule(this, call)
        toast("Zamanlandı: ${fmt.format(Date(when_))}")
        etName.text.clear()
        etNumber.text.clear()
        refreshList()
    }

    private fun refreshList() {
        listCalls.removeAllViews()
        val calls = Store.all(this)
        if (calls.isEmpty()) {
            listCalls.addView(TextView(this).apply { text = "Henüz zamanlanmış arama yok."; setPadding(0, 12, 0, 12) })
        }
        for (c in calls) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 10, 0, 10)
            }
            val info = TextView(this).apply {
                text = "${c.name}  (${c.number})\n${fmt.format(Date(c.time))}" + if (c.daily) "  • her gün" else ""
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val del = Button(this).apply {
                text = "Sil"
                setOnClickListener {
                    Scheduler.cancel(this@MainActivity, c.id)
                    Store.remove(this@MainActivity, c.id)
                    refreshList()
                }
            }
            row.addView(info)
            row.addView(del)
            listCalls.addView(row)
        }
        val log = Store.logLines(this)
        tvLog.text = if (log.isEmpty()) "Kayıt yok." else log.joinToString("\n")
    }

    private fun refreshPermissionBanner() {
        val missing = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            missing += "• Telefon araması izni verilmemiş"
        }
        if (!Scheduler.canScheduleExact(this)) missing += "• 'Alarmlar ve hatırlatıcılar' izni kapalı"
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            missing += "• Pil optimizasyonu açık (arama gecikebilir)"
        }
        permStatus.visibility = if (missing.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE
        btnFixPerms.visibility = permStatus.visibility
        permStatus.text = "Güvenilir çalışması için:\n" + missing.joinToString("\n")
    }

    /** Eksik olan ilk izni ister / ilgili ayar ekranını açar; her dönüşte onResume tekrar kontrol eder. */
    private fun fixPermissions() {
        when {
            checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED ->
                requestPermissions(permissionsToAsk(), 1)
            !Scheduler.canScheduleExact(this) ->
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            !getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName) ->
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshPermissionBanner()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
