package com.example.zamanliarama

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object Scheduler {
    const val DAY = 24L * 60 * 60 * 1000

    fun canScheduleExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    }

    private fun pending(ctx: Context, id: Int): PendingIntent {
        val intent = Intent(ctx, CallReceiver::class.java).putExtra("id", id)
        return PendingIntent.getBroadcast(
            ctx, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /**
     * setAlarmClock: Doze (uyku) modunda bile tam zamanında çalışan en güvenilir alarm türüdür.
     * Durum çubuğunda alarm simgesi gösterir; bu normaldir.
     */
    fun schedule(ctx: Context, call: ScheduledCall): Boolean {
        if (!canScheduleExact(ctx)) return false
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        ctx.getSystemService(AlarmManager::class.java)
            .setAlarmClock(AlarmManager.AlarmClockInfo(call.time, show), pending(ctx, call.id))
        return true
    }

    fun cancel(ctx: Context, id: Int) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, id))
    }

    /** Günlük tekrarlayan bir aramanın bir sonraki gelecekteki zamanı. */
    fun nextFuture(time: Long, now: Long = System.currentTimeMillis()): Long {
        var t = time
        while (t <= now) t += DAY
        return t
    }
}
