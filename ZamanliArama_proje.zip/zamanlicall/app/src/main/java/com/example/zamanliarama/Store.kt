package com.example.zamanliarama

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ScheduledCall(
    val id: Int,
    val name: String,
    val number: String,
    val time: Long,
    val daily: Boolean
)

/** Zamanlanmış aramaları ve kısa bir geçmişi SharedPreferences içinde JSON olarak saklar. */
object Store {
    private const val PREFS = "zamanli_arama"
    private const val KEY_CALLS = "calls"
    private const val KEY_LOG = "log"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun all(ctx: Context): List<ScheduledCall> {
        val raw = prefs(ctx).getString(KEY_CALLS, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            ScheduledCall(
                o.getInt("id"), o.getString("name"), o.getString("number"),
                o.getLong("time"), o.getBoolean("daily")
            )
        }.sortedBy { it.time }
    }

    @Synchronized
    private fun saveAll(ctx: Context, list: List<ScheduledCall>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name).put("number", it.number)
                    .put("time", it.time).put("daily", it.daily)
            )
        }
        prefs(ctx).edit().putString(KEY_CALLS, arr.toString()).apply()
    }

    fun get(ctx: Context, id: Int): ScheduledCall? = all(ctx).firstOrNull { it.id == id }

    fun upsert(ctx: Context, call: ScheduledCall) {
        saveAll(ctx, all(ctx).filter { it.id != call.id } + call)
    }

    fun remove(ctx: Context, id: Int) {
        saveAll(ctx, all(ctx).filter { it.id != id })
    }

    fun nextId(ctx: Context): Int = (all(ctx).maxOfOrNull { it.id } ?: 0) + 1

    @Synchronized
    fun log(ctx: Context, message: String) {
        val stamp = java.text.SimpleDateFormat("dd.MM HH:mm", java.util.Locale("tr")).format(java.util.Date())
        val arr = JSONArray(prefs(ctx).getString(KEY_LOG, "[]"))
        val items = (0 until arr.length()).map { arr.getString(it) }.takeLast(14) + "$stamp  $message"
        prefs(ctx).edit().putString(KEY_LOG, JSONArray(items).toString()).apply()
    }

    fun logLines(ctx: Context): List<String> {
        val arr = JSONArray(prefs(ctx).getString(KEY_LOG, "[]"))
        return (0 until arr.length()).map { arr.getString(it) }.reversed()
    }
}
